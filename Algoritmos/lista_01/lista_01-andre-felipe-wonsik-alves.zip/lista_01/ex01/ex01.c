#include <stdio.h>

int main(){
    printf("------------------------\n");
    printf("[ PROGRAMANDO EM C! ]\n");
    printf("------------------------\n");

    return 0;
}